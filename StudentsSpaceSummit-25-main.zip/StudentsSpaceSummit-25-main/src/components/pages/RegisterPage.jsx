// RegisterPage (/register) http://localhost:3000/register/

import React from 'react';
import Navbar from '../common/Navbar';
import Footer from '../common/Footer';

const RegisterPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-black text-white">
      <Navbar />
      <div className="flex-grow flex items-center justify-center">
        <div className="w-full h-screen bg-purple-900 flex items-center justify-center">
          <h2 className="text-3xl font-bold text-white">Register Page</h2>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default RegisterPage;