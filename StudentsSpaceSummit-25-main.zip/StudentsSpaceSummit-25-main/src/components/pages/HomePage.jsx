// HomePage (/) http://localhost:3000/

import React from "react";
import Navbar from "../common/Navbar";
import Footer from "../common/Footer";
import Hero from "../sections/Hero";
import About from "../sections/About";
import Speakers from "../sections/Speakers";
import PastGlimpses from "../sections/PastGlimpses";
import Schedule from "../sections/Schedule";
import GetInTouch from "../sections/GetInTouch";

const HomePage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-black text-white">
      <Navbar />
      <main className="flex-grow">
        <Hero />
        <About />
        <PastGlimpses />
        <Speakers />
        <Schedule />
        <GetInTouch />
      </main>
      <Footer />
    </div>
  );
};

export default HomePage;
