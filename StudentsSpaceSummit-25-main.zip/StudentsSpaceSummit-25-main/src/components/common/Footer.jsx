// Simple Footer component with links and contacts

import React from 'react';

export default function Footer() {
  return (
    <footer className="w-full bg-gray-900 text-white p-2 flex items-center justify-center">
      <h2 className="text-sm">Footer Component</h2>
    </footer>
  );
}
