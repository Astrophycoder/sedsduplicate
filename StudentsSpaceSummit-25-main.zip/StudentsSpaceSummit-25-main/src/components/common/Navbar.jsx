// Navbar + Hamburger Implementation component

import React from 'react';

export default function Navbar() {
  return (
    <div className="w-full bg-gray-900 text-white p-2 flex items-center justify-center">
      <h2 className="text-sm">Navbar Component</h2>
    </div>
  );
}
