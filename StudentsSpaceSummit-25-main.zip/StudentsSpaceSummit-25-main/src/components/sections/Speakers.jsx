// Speakers section of / page.
import React from 'react';

export default function Speakers() {
  return (
    <div className="w-full min-h-[300px] bg-purple-950 flex items-center justify-center">
      <h2 className="text-3xl font-bold text-white">Speakers Component</h2>
    </div>
  );
}
