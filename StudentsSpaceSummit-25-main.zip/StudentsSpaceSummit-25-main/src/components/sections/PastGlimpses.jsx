"use client";

import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const polaroidData = [
  {
    id: 1,
    classes: 'top-[8%] left-[10%] lg:left-[5%] -rotate-[12deg]',
    src: 'https://cdn.pixabay.com/photo/2023/02/12/13/16/dog-7785066_1280.jpg',
    caption: null,
  },
  {
    id: 2,
    classes: 'top-[5%] left-[28%] lg:left-[26%] -rotate-[4deg]',
    src: 'https://cdn.pixabay.com/photo/2025/08/02/11/04/wood-9750451_1280.jpg',
    caption: null,
  },
  {
    id: 3,
    classes: 'top-[7%] left-[45%] lg:left-[48%] rotate-[6deg]',
    src: 'https://cdn.pixabay.com/photo/2025/08/02/11/04/wood-9750451_1280.jpg',
    caption: 'captions',
  },
  {
    id: 4,
    classes: 'top-[12%] left-[60%] lg:left-[70%] rotate-[14deg]',
    src: 'https://cdn.pixabay.com/photo/2023/02/12/13/16/dog-7785066_1280.jpg',
    caption: null,
  },
  {
    id: 5,
    classes: 'top-[62%] left-[12%] lg:left-[5%] -rotate-[10deg]',
    src: 'https://cdn.pixabay.com/photo/2023/02/12/13/16/dog-7785066_1280.jpg',
    caption: 'captions',
  },
  {
    id: 6,
    classes: 'top-[68%] left-[30%] lg:left-[28%] rotate-[8deg]',
    src: 'https://cdn.pixabay.com/photo/2025/08/02/11/04/wood-9750451_1280.jpg',
    caption: null,
  },
  {
    id: 7,
    classes: 'top-[65%] left-[50%] lg:left-[53%] -rotate-[8deg]',
    src: 'https://cdn.pixabay.com/photo/2023/02/12/13/16/dog-7785066_1280.jpg',
    caption: null,
  },
  {
    id: 8,
    classes: 'top-[60%] left-[58%] lg:left-[75%] rotate-[12deg]',
    src: 'https://cdn.pixabay.com/photo/2023/02/12/13/16/dog-7785066_1280.jpg',
    caption: null,
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const polaroidVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.5,
      ease: 'easeOut',
    },
  },
};

export default function PastGlimpses() {
  return (
    <div
      className="w-full min-h-screen flex items-center justify-center py-20 lg:py-32 bg-[#101418] overflow-hidden"
      style={{
        backgroundImage: 'url("/background.png")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <motion.div
        className="relative w-full max-w-xs sm:max-w-sm md:max-w-2xl lg:max-w-4xl h-[500px] md:h-[600px] lg:h-[650px]"
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
      >
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10 space-y-1 md:space-y-3 pointer-events-none">
          <h2 className="text-4xl sm:text-4xl md:text-5xl lg:text-6xl text-white tracking-widest uppercase font-alternox-bold">
            Past
          </h2>
          <h2 className="text-4xl sm:text-4xl md:text-5xl lg:text-6xl text-white tracking-widest uppercase font-alternox-bold">
            Glimpses
          </h2>
        </div>

        {polaroidData.map((p) => (
          <motion.div
            key={p.id}
            variants={polaroidVariants}
            className={cn(`absolute bg-white p-1.5 pb-6 shadow-lg w-28 h-32 sm:w-32 sm:h-36 md:w-44 md:h-48 md:p-2 md:pb-8 transform transition-transform duration-300 ease-in-out hover:scale-110 hover:!rotate-0 hover:z-20`, p.classes)}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="absolute -top-3 left-1/2 -translate-x-1/2 text-gray-400 w-7 h-7"
            >
              <path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.59a2 2 0 0 1-2.83-2.83l8.49-8.48"></path>
            </svg>
            <div className="w-full h-full bg-black">
              <img
                src={p.src}
                alt={p.caption || 'A past glimpse'}
                className="w-full h-full object-cover"
              />
            </div>
            {p.caption && (
              <p className="absolute bottom-1.5 left-1/2 -translate-x-1/2 bg-white px-2 text-gray-800 italic text-sm md:text-base font-alternox-extrabold whitespace-nowrap">
                {p.caption}
              </p>
            )}
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}