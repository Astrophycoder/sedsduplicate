// Main section of / page.
import React from 'react';

export default function Hero() {
  return (
    <div className="w-full min-h-[300px] bg-blue-950 flex items-center justify-center">
      <h2 className="text-3xl font-bold text-white">Hero Component</h2>
    </div>
  );
}
