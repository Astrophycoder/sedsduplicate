"use client";

import React, { useRef } from 'react';

const ChevronArrow = ({ direction = 'right' }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`w-6 h-6 text-white transition-transform duration-200 group-hover:scale-110 ${direction === 'left' ? 'transform -rotate-180' : ''}`}
  >
    <path d="m9 18 6-6-6-6" />
  </svg>
);


const scheduleData = [
    { time: '8:15 to 8:50', title: 'Registration', isCurrent: true },
    { time: '9:00 to 9:40', title: 'Inauguration' },
    { time: '9:40 to 9:55', title: 'Refreshments' },
    { time: '10:00 to 10:55', title: 'Talk 1' },
    { time: '11:00 to 11:55', title: 'Talk 2' },
    { time: '12:00 to 12:45', title: 'Talk 3' },
    { time: '12:45 to 2:00', title: 'Lunch Break' },
    { time: '2:00 to 5:00', title: 'Workshop' },
    { time: '5:00 to 5:15', title: 'Refreshments' },
];

const ScheduleItem = ({ time, title, isCurrent }) => {
    const [timeStart, , timeEnd] = time.split(' ');
    return (
        <div className="relative flex flex-col items-center justify-start flex-shrink-0 mx-4 z-10" style={{ width: '120px' }}>
            <div className={`bg-[#1a1f2c] text-white text-xs font-mono rounded-md py-2 px-3 text-center shadow-lg transition-all duration-300 ring-1 ${isCurrent ? 'ring-cyan-400' : 'ring-slate-700'}`}>
                <p>{timeStart}</p><p>to</p><p>{timeEnd}</p>
            </div>
            <div className={`w-5 h-5 bg-white rounded-full my-4 border-4 shadow-md z-10 transition-all duration-300 ${isCurrent ? 'border-cyan-400 shadow-[0_0_15px_rgba(103,232,249,0.7)]' : 'border-[#1a1f2c]'}`}></div>
            <div className={`bg-slate-800/20 backdrop-blur-sm rounded-lg p-3 w-20 h-48 flex items-center justify-center shadow-2xl transition-all duration-300 ring-1 ${isCurrent ? 'ring-cyan-400 shadow-[0_0_20px_rgba(103,232,249,0.4)]' : 'ring-slate-700/50'}`}>
                <p className="transform -rotate-90 whitespace-nowrap text-lg font-semibold tracking-wider text-white">{title}</p>
            </div>
        </div>
    );
};

export default function Schedule() {
    const scrollContainerRef = useRef(null);

    const handleScroll = (scrollOffset) => {
        if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollBy({ left: scrollOffset, behavior: 'smooth' });
        }
    };

    return (
        <div className="w-full py-20 lg:py-32 bg-[#101418] overflow-hidden" style={{ backgroundImage: 'url("/background.png")', backgroundSize: 'cover', backgroundPosition: 'center' }}>
            <div className="container mx-auto">
                <h2 
                  className="text-4xl md:text-5xl text-white text-center font-bold tracking-widest uppercase mb-20 font-alternox-bold px-4"
                  style={{ textShadow: '0 0 15px rgba(103, 232, 249, 0.5)' }}
                >
                  Event Schedule
                </h2>
                
                <div className="relative">
                    <button
                        onClick={() => handleScroll(-300)}
                        className="absolute left-2 top-1/2 -translate-y-1/2 z-30 p-3 bg-slate-800/60 backdrop-blur-sm rounded-full ring-1 ring-cyan-400/50 md:hidden group"
                        aria-label="Scroll left"
                    >
                        <ChevronArrow direction="left" />
                    </button>
                    <button
                        onClick={() => handleScroll(300)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 z-30 p-3 bg-slate-800/60 backdrop-blur-sm rounded-full ring-1 ring-cyan-400/50 md:hidden group"
                        aria-label="Scroll right"
                    >
                        <ChevronArrow direction="right" />
                    </button>

                    <div ref={scrollContainerRef} className="w-full overflow-x-auto pb-10 hide-scrollbar">
                        <div className="relative" style={{ minWidth: '1500px' }}>
                            <div className="absolute top-[88px] left-0 w-full h-1.5 bg-cyan-400 rounded-full" style={{boxShadow: '0 0 10px rgba(103, 232, 249, 0.6)'}}></div>
                            <img src="/comet.png" alt="Comet effect" className="absolute right-[-60px] top-2 w-auto h-36 z-20 pointer-events-none" />
                            <div className="relative flex items-start px-8 font-alternox-extralight">
                                {scheduleData.map((item, index) => (
                                    <ScheduleItem key={index} time={item.time} title={item.title} isCurrent={item.isCurrent} />
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}