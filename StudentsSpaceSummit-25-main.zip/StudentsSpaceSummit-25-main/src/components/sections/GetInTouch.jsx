// Get in Touch section of / page.
import React from 'react';

export default function GetInTouch() {
  return (
    <div className="w-full min-h-screen bg-slate-900 relative overflow-hidden bg-cover bg-center bg-no-repeat" style={{ backgroundImage: "url('/background.png')" }}>
      <div className="flex flex-col items-center justify-center min-h-screen px-4 py-16">
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-white font-alternox-bold text-center mb-16 tracking-wider">
          GET IN TOUCH
        </h1>
        
        <div className="text-center mb-12">
          <p className="text-white text-xl md:text-2xl font-alternox-regular mb-2">
            Have any questions?
          </p>
          <p className="text-white text-xl md:text-2xl font-alternox-regular">
            Reach out to our event coordinators
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-8 max-w-4xl w-full">
          <div className="bg-slate-400/10 backdrop-blur-sm rounded-3xl p-8 flex-1 text-center">
            <h3 className="text-white-800 text-xl font-alternox-bold mb-2">
              Kailas Sachdev
            </h3>
            <p className="text-white-800 text-lg font-alternox-regular mb-1">
              President
            </p>
            <p className="text-white-800 text-lg font-alternox-regular mb-6">
              IRES SEDS CUSAT
            </p>
            <div className="space-y-2">
              <p className="text-white-800 font-alternox-regular">
                Phone : xxxxxx
              </p>
              <p className="text-white-800 font-alternox-regular">
                Mail : xxxxxxxxx
              </p>
            </div>
          </div>

          <div className="bg-slate-400/10 backdrop-blur-sm rounded-3xl p-8 flex-1 text-center">
            <h3 className="text-white-800 text-xl font-alternox-bold mb-2">
              Asiya
            </h3>
            <p className="text-white-800 text-lg font-alternox-regular mb-1">
              Secretary
            </p>
            <p className="text-white-800 text-lg font-alternox-regular mb-6">
              IRES SEDS CUSAT
            </p>
            <div className="space-y-2">
              <p className="text-white-800 font-alternox-regular">
                Phone : xxxxxx
              </p>
              <p className="text-white-800 font-alternox-regular">
                Mail : xxxxxxxxx
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}