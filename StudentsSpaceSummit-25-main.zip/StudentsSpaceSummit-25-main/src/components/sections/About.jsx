// About Us section of / page.
import React from 'react';

export default function About() {
  return (
    <div className="w-full min-h-screen bg-slate-900 relative overflow-hidden bg-cover bg-center bg-no-repeat " style={{ backgroundImage: "url('/background.png')" }}>
      <div className="flex flex-col items-center justify-center min-h-screen px-4 py-16">
        <h1 className="text-5xl sm:text-4xl md:text-6xl lg:text-7xl text-white font-alternox-bold text-center mb-16 tracking-wider">
          ABOUT THE SUMMIT
        </h1>
        <div className="max-w-4xl mx-auto rounded-3xl p-8 md:p-12">
          <div className="text-white-800 space-y-6">
            <p className="text-lg md:text-xl text-center font-alternox-regular leading-relaxed">
              Students Space Summit is an Annual event
              for space enthusiasts, and budding Astronomer students in schools,
              conducted by <span className='font-alternox-bold text-blue-400'>IRES SEDS CUSAT</span> to spark their curiosity,
              share information, and give opportunity to
              the interested students
              to explore their love for space and Astronomy.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
