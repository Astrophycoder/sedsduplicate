import RegisterPage from "@/components/pages/RegisterPage";

// Register page
export default function Register() {
  return <RegisterPage />;
}
